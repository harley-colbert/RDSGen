from ..config import SettingsManager

# Shared app-level dependencies (singletons)
settings_mgr = SettingsManager()
